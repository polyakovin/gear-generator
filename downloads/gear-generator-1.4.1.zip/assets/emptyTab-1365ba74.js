import{c as o,j as t,R as r,A as s}from"./chunk-7dc3dd44.js";import"./chunk-3bf3d833.js";const e=document.getElementById("app");e&&o.createRoot(e).render(t.jsx(r.StrictMode,{children:t.jsx(s,{})}));
